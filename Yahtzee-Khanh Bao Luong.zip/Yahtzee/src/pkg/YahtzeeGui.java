package pkg;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;

public class YahtzeeGui {
	 static int rollremain = 5;

    public static void main(String[] args) {
    
        JFrame frame1 = new JFrame();
        frame1.setTitle("Yahtzee");
        frame1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame1.setSize(1920, 1080);
        frame1.setResizable(false);
        frame1.setBackground(null);

        
        ImageIcon background = new ImageIcon("Backgound.png"); 
        Image backgroundImage = background.getImage().getScaledInstance(1920, 1080, Image.SCALE_SMOOTH);  
        background = new ImageIcon(backgroundImage);
        JLabel label1 = new JLabel();
        label1.setIcon(background);
        label1.setLayout(null);
        
        
        Button rollButton = new Button("Roll");
         
        int buttonWidth = 180;  
        int buttonHeight = 80; 
        int xPosition = (frame1.getWidth() - buttonWidth) / 2; 
        int yPosition = 850;
  
        JLabel RollLeft = new JLabel("Roll Left: " + rollremain);     
        int gap = 10;  
        int labelX = (frame1.getWidth() - (buttonWidth + 200 + gap)) / 2; 
        rollButton.setBounds(labelX, 850, 180, 80);
        rollButton.setFont(new Font("Arial", Font.BOLD, 40));
        rollButton.setForeground(Color.WHITE);
        rollButton.setFocusPainted(false);        
        RollLeft.setBounds(labelX + buttonWidth + gap, 850, 400, 80);
        RollLeft.setForeground(Color.WHITE);
        RollLeft.setFont(new Font("Pixel Emulator", Font.BOLD,40));


        rollButton.addActionListener(e -> 
        {
            if (rollremain > 0) 
            {
                rollremain--;  
                RollLeft.setText("Roll Left: " + rollremain);  
            }
          
        });
        
       
       
        label1.add(RollLeft);
        label1.add(rollButton);

        frame1.add(label1);
        frame1.setVisible(true);
    }
}
