/**
 * 
 */
/**
 * 
 */
module Yahtzee {
	requires java.desktop;
}